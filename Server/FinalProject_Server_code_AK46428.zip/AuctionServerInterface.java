public interface AuctionServerInterface {

    void loadItemsFromFile(String string);

}